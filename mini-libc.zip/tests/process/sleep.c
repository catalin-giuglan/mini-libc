// SPDX-License-Identifier: BSD-3-Clause

#include <unistd.h>

int main(void)
{
	sleep(10);

	return 0;
}
