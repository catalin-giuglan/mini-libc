// SPDX-License-Identifier: BSD-3-Clause

#include <stdio.h>

int main(void)
{
	puts("Hello, World!");

	return 0;
}
